<?php
/*
 * All default option are set here
 * configure them via the settings page
 */


 
//Slugs - Sections of site urls used when accessing plugin pages e.g. my-site.com/wp-librarian

//The slug for library items
add_option( 'wp_lib_slug', 'wp-librarian' );

//The slug for viewing authors
add_option( 'wp_lib_authors_slug', 'authors' );

//The slug for viewing media types
add_option( 'wp_lib_media_type_slug', 'type' );

//The slug for viewing donors
add_option( 'wp_lib_donors_slug', 'donors' );

//The slug for viewing members
add_option( 'wp_lib_members_slug', 'members' );

/* Formatting and Customisation - Small tweaks to plugin presentation */
// Whether to create default media types if they don't already exist
add_option( 'wp_lib_default_media_types', true );

//The separator for item taxonomies (the comma between authors)
add_option( 'wp_lib_taxonomy_spacer', ', ' );




?>