<?php
/*
 * The generally useful hooks and functions file
 *
 */

// Prepares taxonomy and metabox information for theme use
function wp_lib_fetch_meta( $the_post_id ) {
	//Metabox data is fetched then, if needed, sent to wp_lib_prep_meta to be formatted
	$meta_array = array(
		'media type'	=> apply_filters( 'wp_lib_format_meta', get_the_terms( $the_post_id, 'wp_lib_media_type' ), 'wp_lib_media_type_slug', 'media-type', 'Media Type' ),
		'authors'		=> apply_filters( 'wp_lib_format_meta', get_the_terms( $the_post_id, 'wp_lib_author' ), 'wp_lib_authors_slug', 'authors', 'Author' ),
		'donor'			=> apply_filters( 'wp_lib_format_meta', get_the_terms( $the_post_id, 'wp_lib_donor' ), 'wp_lib_donors_slug', 'donors', 'Donor' ),
		'isbn'			=> apply_filters( 'wp_lib_format_meta', get_post_meta( $the_post_id, 'wp_lib_item_isbn', false ), false, false, 'ISBN' ),
	);
	// Checks if book is allowed to be loaned and if the book isn't already on loan
	//$loan_allowed = get_the_terms( $the_post_id, 'wp_lib_item_available' );
	$loan_allowed = true;
	$loan_already = get_the_terms( $the_post_id, 'wp_lib_member' );
	var_dump( $loan_allowed);
	if ( $loan_already != false )
		$loan_already = true;
	if ( $loan_allowed == true && $loan_already == false )
		$meta_array['available'] = '<strong>Status: </strong><a href="http://nowhere.com">Available</a>';
	else
		$meta_array['available'] = '<strong>Status:</strong> Unavailable';
	$all_meta = '';
	//echo var_dump( $meta_array );
		foreach ( $meta_array as &$value ) {
			if ( $value != false )
				$all_meta .= $value . '<br />';
		}
	return $all_meta;
}

// Formats author/media type/donor arrays and formats them as a comma separated list with hyperlinks
function wp_lib_prep_meta( $raw_array, $option_name, $option_default_slug, $bold_name ){
	if ( $raw_array != false ){
		// If there is one than one of a taxonomy item it makes the term plural (Author -> Authors)
		if ( count( $raw_array ) > 1 ) {
			$plural = 's:</strong> ';
		} else {
			$plural = ':</strong> ';
		}
		
		// The begining of a meta value is composed using the meta name e.g. 'ISBN: '
		$item_string = '<strong>' . $bold_name . $plural;

		//Each taxonomy item is formatted as a hyperlink and every item after the firt is preceded with $spacer (a comma by default)
		$count = 0;
		foreach ( $raw_array as $item ) {
			$count++;
			$spacer = '';
			if ( $count > 1 )
				$spacer .= get_option( 'wp_lib_taxonomy_spacer', ', ' );
			if ( isset( $item->slug ) ) {
				$tax_url = get_option( 'siteurl', 'example.com/' );
				$tax_slug = apply_filters( 'wp_lib_prefix_url', $option_name, $option_default_slug );
				$item_string .= "{$spacer}<a href=\"{$tax_url}/{$tax_slug}/{$item->slug}\">{$item->name}</a>";
			}
			else
				$item_string .= $spacer . $item;
		}
		return $item_string;
	}
}

// Loads relevant archive template from the current theme
// If it doesn't exist it uses its built in template file
function wp_lib_template( $template ) {
	if ( get_post_type() == 'wp_lib_items' ) {
		if ( is_archive() ) {
			$theme_file = locate_template( array ( 'archive-wp_lib_items.php' ) );
			if ($theme_file != ''){
				return $theme_file;
			}
			else {
				return plugin_dir_path(__FILE__) . '/templates/archive-wp_lib_items.php';
			}
		}
		elseif ( is_single() ) {
			$theme_file = locate_template( array ( 'single-wp_lib_items.php' ) );
			if ($theme_file != ''){
				return $theme_file;
			}
			else {
				return plugin_dir_path(__FILE__) . '/templates/single-wp_lib_items.php';
			}
		}
	}
	return $template;
}

// Santizes HTML POST data from a checkbox
function wp_lib_sanitize_checkbox( $raw ) {
	if ( $raw == 'true' )
		return true;
	else
		return '';
}

// Removes unwanted description field from taxonomies list
function wp_lib_no_tax_description() { ?>
	<script type="text/javascript">
    jQuery(document).ready( function($) {
        $('#tag-description').parent().remove();
    });
    </script>
	<?php
}

// Removes unwanted description field from taxonomy item edit page
function wp_lib_no_tax_edit_description() { ?>
	<script type="text/javascript">
    jQuery(document).ready( function($) {
        $('#description').parents().eq(1).remove();
    });
    </script>
	<?php
}

// Clears taxonomy metadata (stored as options) on deletion
function wp_lib_clear_tax_options( $tt_id ) {
	update_option( "wp-lib-testing-option", $tt_id );
	delete_option( "taxonomy_{$tt_id}" );
}

// Adds plugin url to front of string (e.g. authors -> library/authors)
function wp_lib_prefix_url( $option, $slug ) {
	$main_slug = get_option( 'wp_lib_slug', 'wp-librarian' );
	$sub_slug = get_option( $option, $slug );
	$full_slug = $main_slug . '/' . $sub_slug;
	return $full_slug;
}

?>